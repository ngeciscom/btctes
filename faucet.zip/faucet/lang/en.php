<?php

//PAGINA INICIO (index.php) --------------------------------------------------------------------------------------------
$modo = "Rotator Mode";


//PAGINAS DE FAUCET -----------------------------------------------------------------------------------------------

$sis_pago = 'Payment system: ';
$Cause =	'Cause: ';
$nom_cont =	'E-Mail: ';
$env_rep =	'Send report';
$credit = 	'© 2015 <b>Bitcoin Finder</b> Rotador de faucets';
$ver =		'Visit';
$contact =	'Contact';
$about =	'About';
$remover =	'Remove this faucet listing';
$show_hide ='View list';
$show_hide_desc ='See all faucets of this list';

// FORMULARIO DE REPORTE 
$rep_de =	'Faucet report:';
$send_by =	'Send by:';
$Cause_rep= 'Cause:';
$check =	'check';
$cancelar =	'Cancel';
$envio_ok = 'The report has been sent successfully, the faucet was removed from the list.';
$envio_ok_ ='Thanks for collaborating with the site!';
$envio_fail = 'The report could not be sent, try again later ...';
$fail 		= 'Could not open the file...';
$solicitud  = 'Application for membership received.';

//PANEL ADMINISTRATIVO ---------------------------------------------------------------------------------------------
$gen_conf =		'General settings';
$elim_rep =		'Delete reports';
$reg_borrados=  'Reports deleted...';
$add_fau =		'Add';
$id_fau =		'Faucet ID:';
$id_fau_desc =	'(Use only the ID number - ej:01,02,10,12)';
$reemp =		'Edit';
$reemp_btn =	'Edit faucet';
$list_fau =		'List of Faucets';
$list_fau_desc= 'See all faucets';
$notific =		'Notifications';
$conf =			'Settings';
$home =			'Ir al sitio';
$salir =		'Logout';
$add_fau_btn =	'Add faucet';
$nom_fau =		'Faucet name:'; 
$tiempo_esp =	'Wait time:';
$pago_min = 	'Minimum payment:';
$sist_pago =	'Payment system:';
$reco_fau_ =		'Recommending faucet';
$selec_list = 	'Select the list:';
$preview_	  = 'Preview';
$referer_type = 'Referer type:';
$referer_type_ = 'Custom / other';
$active_faucet = 'Faucet enabled';
$activ =  		 ' active Faucet ';
$publicidades =	 'Advertising';
$no_publicidad = 'Disable ADs';
$ubicacion_panel = 'Side panel location:';
$u_panel_i = 	 'Left';
$u_panel_d = 	 'Right';
$panel_config =  'Color and width of the panel';
$html_cod_ad = 	 'Html Code of ADs';
$adbit01 =		 'Need an AdBit account?';
$adbit02 =		 'Click here...';
$edit_btn = 	 'Edit';
$edit_btn_desc = 'Edit the values of a faucet';


//PANEL ADMINISTRATIVO (CONFIGURACIONES) -----------------------------------------------------------------------------
$dir_cartera =	'Wallet address';
$guardar_conf =	'Save';
$conf_title =	'Site Settings';
$nombre_sitio =	'Domain name (Url base)';
$idioma_sitio =	'Site Language';
$subir_img_title =	'image upload';	
$subir_desc =	'Select an image to upload.';	
$subir_img =	'Upload';
$site_title = 	'powered by nechuz';
$img_desc0 =	'Dimensions:';
$pag_name = 	'Website title';
$pag_desc = 	'Website description';
$pag_tags =		'Tags';
$motivo ="";

<?php
//¡NO TOCAR ESTOS VALORES!
$domain_code = 'bitcoinfinder';	
$random_num_1 = 20;		
$random_num_2 = 565;		
$random_num_3 = 3;			

//'usuario' => 'contraseña'
$users = array(
		'tes' => 'tes'
	);


?>
<?php

// URL BASE DEL SITIO
//ES MUY IMPORTANTE DEJAR LA BARRA CRUZADA "/" AL FINAL DE LA URL
$url_base = "http://localhost/faucet/"; 

// DIRECCION DE LA CARTERA PARA LOS REFERERS
$wallet_addr = "3JuwvthEVgkBAEsLXysWr5qCvJRMU8wLVd";

// IDIOMA DEL SITIO 
$lang = "/lang/en.php";
$lang_ = "principal.php";

// DESCRIPCION DEL SITIO
$descripcion = "BTF4 es un listado de faucet para ganar bitcoins";

// TAGS DEL SITIO
$tags_site = "Bitcoin, BTC, Satoshi, faucet, faucetlist, faucet-list, rotator, free bitcoins, earn Bitcoins, win, money, make, win and play, Earn money, Win free Bitcoins, ePay, Xapo, FaucetBox";

// TITULO DEL SITIO
$title = "BTCF4";

// CODIGO PUBLICIDAD 1
$html_ads1 = '';

// CODIGO PUBLICIDAD 2
$html_ads2 = '';

// CODIGO PUBLICIDAD 3
$html_ads3 = '';

// CODIGO PUBLICIDAD 4
$html_ads4 = '';

// CODIGO PUBLICIDAD 5
$html_ads5 = '';

// IMAGENES DE FONDO
$background_img = $url_base . "img/fondo.jpg";
?>
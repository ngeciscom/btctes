<?php 
require('_login.php'); 
header("LOCATION: index.php");
?>
<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="enabled";

// DATOS DE LA FAUCET --------
$s_pago = "epay";

$ID_name = "Million Satoshi";
$dir_web = "http://www.MilionSatoshi.com";

$tipo_ref = "'.$dir_web.'/?='.$wallet_addr.'";

$pago = "135";
$tiempo = "10";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = '';
$ad2 = '';
$ad3 = '';
$ubic = "right";
$ancho = "0";
$color = "#404040";
$ancho2 = "220";
$no_ad = "yes";
$nota = "";
?>
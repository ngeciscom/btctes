<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="disabled";

// DATOS DE LA FAUCET --------
$s_pago = "faucetbox";

$ID_name = "BitHeaven";
$dir_web = "http://bitheaven.io";

$tipo_ref = "'.$dir_web.'/?='.$wallet_addr.'";

$pago = "250";
$tiempo = "30";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = '';
$ad2 = '';
$ad3 = '';
$ubic = "right";
$ancho = "0";
$color = "#E0E0E0";
$ancho2 = "220";
$no_ad = "yes";
$nota = "";
?>
<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="enabled";

// DATOS DE LA FAUCET --------
$s_pago = "faucetbox";

$ID_name = "Happy Putin";
$dir_web = "http://faucet.happyputin.com";

$tipo_ref = "'.$dir_web.'/?='.$wallet_addr.'";

$pago = "225";
$tiempo = "61";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = '<center>
	<div>
		<iframe scrolling="no" frameborder="0" src="//adbit.co/adspace.php?a=C818IU2243QEM" style="overflow:hidden;width:200px;height:200px;"></iframe>
	</div>
	<div>
		<a href="//adbit.co/?a=Advertise&b=View_Bid&c=C818IU2243QEM" target="_blank">⇑ Your Ad Here ⇑</a>
	</div>
</center>';
$ad2 = '<center>
	<div>
		<iframe scrolling="no" frameborder="0" src="//adbit.co/adspace.php?a=U4O1CVWZYL7MV" style="overflow:hidden;width:200px;height:200px;"></iframe>
	</div>
	<div>
		<a href="//adbit.co/?a=Advertise&b=View_Bid&c=U4O1CVWZYL7MV" target="_blank">⇑ Your Ad Here ⇑</a>
	</div>
</center>';
$ad3 = '<center>
	<div>
		<iframe scrolling="no" frameborder="0" src="//adbit.co/adspace.php?a=NDWX9RK9YZ6U3" style="overflow:hidden;width:200px;height:200px;"></iframe>
	</div>
	<div>
		<a href="//adbit.co/?a=Advertise&b=View_Bid&c=NDWX9RK9YZ6U3" target="_blank">⇑ Your Ad Here ⇑</a>
	</div>
</center>';
$ubic = "right";
$ancho = "220";
$color = "#E02609";
$ancho2 = "220";
$no_ad = "no";
$nota = "";
?>
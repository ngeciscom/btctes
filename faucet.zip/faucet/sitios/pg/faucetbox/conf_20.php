<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="enabled";

// DATOS DE LA FAUCET --------
$s_pago = "faucetbox";

$ID_name = "We love BTC";
$dir_web = "http://welovebtc.com/?ref=3JuwvthEVgkBAEsLXysWr5qCvJRMU8wLVd";

$tipo_ref = "'.$dir_web.'";

$pago = "100";
$tiempo = "61";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = '';
$ad2 = '';
$ad3 = '';
$ubic = "left";
$ancho = "220";
$color = "#636363";
$ancho2 = "220";
$no_ad = "no";
$nota = "";
?>
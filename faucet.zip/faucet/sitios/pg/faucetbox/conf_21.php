<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="enabled";

// DATOS DE LA FAUCET --------
$s_pago = "faucetbox";

$ID_name = "Wiki-coin";
$dir_web = "http://wiki-coin.ru";

$tipo_ref = "'.$dir_web.'/?='.$wallet_addr.'";

$pago = "310";
$tiempo = "61";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = '';
$ad2 = '';
$ad3 = '';
$ubic = "left";
$ancho = "220";
$color = "#999999";
$ancho2 = "220";
$no_ad = "no";
$nota = "";
?>
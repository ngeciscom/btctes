<?php

// ESTADO DE LA FAUCET (HABILITADA/DESHABILITADA)
$status ="enabled";

// DATOS DE LA FAUCET --------
$s_pago = "faucetbox";

$ID_name = "FuLLCoin";
$dir_web = "http://www.fullcoin.ws";

$tipo_ref = "'.$dir_web.'/?='.$wallet_addr.'";

$pago = "160";
$tiempo = "60";
$reco_fau = '<img height="25" width="25" border=0 hspace=1 vspace=1 src="../img/reco_ico.png">';

// ADS -----------------------
$ad1 = 'Cód.Html 1 ';
$ad2 = 'Cód.Html 2 ';
$ad3 = 'Cód.Html 3 ';
$ubic = "right";
$ancho = "300";
$color = "#575F70";
$ancho2 = "220";
$no_ad = "no";
$nota = "";
?>